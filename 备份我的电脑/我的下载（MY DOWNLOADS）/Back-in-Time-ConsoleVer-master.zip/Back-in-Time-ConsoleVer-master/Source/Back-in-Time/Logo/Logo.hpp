#pragma once

#include "../Animation/Animation.hpp"
#include "../Renderer/Renderer.hpp"
#include "../Exception/Exception.hpp"
#include "../Dependencies/Z2APIs.hpp"

#include <memory>

namespace BiTCV
{
	namespace Logo
	{
		class B4Logo
		{
		public:
			B4Logo()
			{
				real_logo = std::make_shared<Animation::B4Animation>();
			}
			void active()
			{
				real_logo->active();
			}
		private:
			std::shared_ptr<Animation::B4Animation> real_logo;
		};
	}
}