#pragma once

#include "../Dependencies/Z2APIs.hpp"
#include "../Database/Database.hpp"

#include <iostream>

namespace BiTCV
{
	namespace UI
	{
		class Grid
		{
		public:
			Grid(short _x, short _y, int _color, int _type) :x(_x), y(_y), color(_color), type(_type) {}
			virtual ~Grid() = default;
			inline virtual void renderSelf(const Database::B4Database &db) const
			{
				Z2Utility::setColor(color);
				Z2Utility::moveCursor(x, y);
				std::cout << db.types_of_grids[type];
			}

			short x = 0;
			short y = 0;
			int color = 10;
			int type = 0;
		};

		// ע�����ڿ��ַ�
		class WideGrid :public Grid
		{
		public:
			WideGrid(short _x, short _y, int _color, int _type) :Grid(_x, _y, _color, _type) {}
			inline virtual void renderSelf(const Database::B4Database &db) const override
			{
				Z2Utility::setColor(color);
				Z2Utility::moveCursor(x + x, y);
				std::cout << db.types_of_w_grids[type];
			}
		};
	}
}
