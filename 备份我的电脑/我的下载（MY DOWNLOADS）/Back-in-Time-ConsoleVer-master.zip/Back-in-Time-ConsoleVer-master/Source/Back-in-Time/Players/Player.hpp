#pragma once

namespace BiTCV
{
	namespace Player
	{
		class B4Player
		{
		public:

		};
	}
}
