#pragma once

#include "../Dependencies/Z2APIs.hpp"
#include "InitalizaionError.hpp"

#include <fstream>
#include <iostream>
#include <ctime>

namespace BiTCV
{
	namespace Exception
	{
		// ע���ṩһЩ����������ͬʱҲ��Ϊ���������쳣�����
		class B4Exception
		{
		public:
			void outputLog(const std::string &log) const
			{
				std::ofstream out("bitcv.log", std::ofstream::trunc);
				out << "[" << std::clock() << "] " << log << std::endl;
			}
			void showInfo(const std::string &info) const
			{
				outputLog(info);
				Z2Utility::setColor(3);
				std::cout << info << std::endl;
			}
			void showError(const std::string &error) const
			{
				outputLog(error);
				Z2Utility::setColor(4);
				std::cout << error << std::endl;
			}
			void showWarning(const std::string &warning) const
			{
				outputLog(warning);
				Z2Utility::setColor(6);
				std::cout << warning << std::endl;
			}
			InitError getInitError()
			{
				//return InitError();
			}
		};
	}
}
