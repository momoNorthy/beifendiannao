#pragma once

#include <stdexcept>

namespace BiTCV
{
	namespace Exception
	{
		class InitError :public std::logic_error
		{
		public:
			//InitError()
		};
	}
}