#pragma once

namespace BiTCV
{
	namespace Map
	{
		class B4Map
		{
		public:
		};
	}
}