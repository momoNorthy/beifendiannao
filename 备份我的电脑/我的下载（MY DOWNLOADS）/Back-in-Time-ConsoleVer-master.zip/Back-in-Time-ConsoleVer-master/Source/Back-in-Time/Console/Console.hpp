#pragma once

namespace BiTCV
{
	namespace Console
	{
		class B4Console
		{

		};
	}
}