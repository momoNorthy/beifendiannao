#pragma once

#include <thread>
#include <chrono>

namespace Z2Utility
{
	namespace
	{
		inline void sleepFor(const int &milliseconds)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(milliseconds));
		}
	} // Unnamed namespace
} // Namespace Z2Utility
