#pragma once

#include <vector>
#include <random>
#include <ctime>

#ifdef WIN32
#include <Windows.h>
#include <conio.h>
#endif

namespace Z2Utility
{
	namespace
	{
		template <typename T>
		void randomizeArray(std::vector<T> &array)
		{
			int size = array.size() - 1;
			std::default_random_engine engine;
			for (int i = 0; i < size; i++)
			{
				engine.seed(std::clock());
				std::uniform_int_distribution<int> udtb(i + 1, size);
				int target_index = udtb(engine);
				auto lobj = array[i];
				array[i] = array[target_index];
				array[target_index] = lobj;
			}
		}

		template <typename T>
		void quickSort(std::vector<T> &array)
		{

		}

		template <typename T>
		void bubbleSort(std::vector<T> &array)
		{

		}
	} // Unnamed namespace
} // Namespace Z2Utility
