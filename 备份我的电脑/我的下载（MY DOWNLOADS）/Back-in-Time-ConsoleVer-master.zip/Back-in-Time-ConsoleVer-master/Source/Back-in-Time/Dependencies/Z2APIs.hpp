#pragma once

#ifdef WIN32
#include <conio.h>
#include <Windows.h>
#endif

#include <cstdlib>
#include <cstdio>

namespace Z2Utility
{
#ifdef WIN32
	namespace
	{
		namespace GlobalVariable
		{
			HANDLE handle;
		}

		void initWINAPIs()
		{
			GlobalVariable::handle = GetStdHandle(STD_OUTPUT_HANDLE);
		}

		inline void setColor(const int &colorIndex)
		{
			SetConsoleTextAttribute(GlobalVariable::handle, colorIndex);
		}

		inline void moveCursor(const short &x, const short &y)
		{
			COORD position{ x,y };
			SetConsoleCursorPosition(GlobalVariable::handle, position);
		}

		inline void clear()
		{
			std::system("cls");
		}

		void setTitle(const std::string &title)
		{
			SetConsoleTitle(title.c_str());
		}

		void setConsoleWindowSize(const int &width, const int &height)
		{
			char command[40];
			sprintf_s(command, "mode con cols=%d lines=%d", width, height);
			std::system(command);
		}
	} // Unnamed namespace
#endif
} // Namespace Z2Utility
