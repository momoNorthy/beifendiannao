#pragma once

#include <fstream>
#include <string>
#include <sstream>

namespace Z2Utility
{
	std::string readAll(const std::string &path)
	{
		std::stringstream ssm;
		std::ifstream in(path, std::ifstream::in);
		ssm << in.rdbuf();
		return ssm.str();
	}
}