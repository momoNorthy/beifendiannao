#pragma once

#include "Weapon.hpp"

namespace BiTCV
{
	namespace Item
	{
		class Sword :public Weapon
		{
		public:
		protected:
			int weapon_type = WEAPON_SWORD;
		};
	}
}