#pragma once

#include "../UI/Grid.hpp"
#include "../Database/Database.hpp"

#include <vector>
#include <memory>

namespace BiTCV
{
	namespace Renderer
	{
		class B4Renderer
		{
		public:
			// ע�����Database��pointer��
			explicit B4Renderer(std::shared_ptr<Database::B4Database> p_database) :database(p_database) {}
			inline void renderGrid(const UI::Grid *grid) const
			{
				grid->renderSelf(*database);
			}
			inline void renderGrids(const std::vector<UI::Grid*> &grids)
			{
				for (const auto &p_grid : grids)
				{
					p_grid->renderSelf(*database);
				}
			}
		private:
			std::shared_ptr<Database::B4Database> database;
		};
	}
}
