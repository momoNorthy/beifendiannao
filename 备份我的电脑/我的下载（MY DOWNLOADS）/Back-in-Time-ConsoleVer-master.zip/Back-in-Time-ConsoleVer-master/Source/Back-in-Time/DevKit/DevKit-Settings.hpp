#pragma once

#include "../Renderer/Renderer.hpp"
#include "../Dependencies/Z2APIs.hpp"

#include <memory>
#include <conio.h>
#include <iostream>

namespace BiTCV
{
	namespace DevKit
	{
		class DKSettings
		{
			friend class B4DevKit;
		public:
			void on()
			{

			}
			void drawInterface()
			{
				Z2Utility::setColor(10);
				Z2Utility::moveCursor(10, 10);
			}
			void getAndProcessInput()
			{
				while (1)
				{
					input = _getch();
				}
			}
		private:
			std::shared_ptr<Renderer::B4Renderer> renderer;
			int input = 0;
		};
	}
}
