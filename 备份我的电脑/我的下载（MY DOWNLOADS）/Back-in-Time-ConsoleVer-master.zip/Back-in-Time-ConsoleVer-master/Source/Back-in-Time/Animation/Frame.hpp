#pragma once

#include "../UI/Grid.hpp"
#include "../Dependencies/Z2File.hpp"

#include <vector>
#include <memory>

namespace BiTCV
{
	namespace Animation
	{
		class Frame
		{
		public:
			std::vector<std::shared_ptr<UI::Grid>> content;
		};
	}
}
