#pragma once

#include <string>
#include <iostream>

namespace BiTCV
{
	namespace Database
	{
		class Index_Parser
		{
		public:
			explicit Index_Parser(std::string &&raw) :index_data(raw) {}
			void parse() const
			{
				std::string line;
				while (std::getline(std::cin, line))
				{
					;
				}
			}
		private:
			std::string index_data;
		};
	}
}
