#pragma once

#include "../Dependencies/Z2File.hpp"
#include "Index_Parser.hpp"

#include <string>
#include <map>
#include <vector>
#include <memory>
#include <array>

namespace BiTCV
{
	namespace Database
	{
		class B4Database
		{
		public:
			B4Database()
			{
				types_of_grids[0] = "*";
				types_of_w_grids[0] = "��";
			}

			void loadItemData()
			{
				// ע����ȡ��Ʒ�����ļ��������vpk����
				std::make_shared<Index_Parser>(Z2Utility::readAll("Resource/Items/index.bitcv.db"));
			}

			std::array<std::string, 4> types_of_grids;
			std::array<std::string, 4> types_of_w_grids;
		private:
			std::shared_ptr<Index_Parser> parser;
		};
	}
}
